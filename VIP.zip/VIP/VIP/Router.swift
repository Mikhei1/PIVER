//
//  Router.swift
//  VIP
//
//  Created by User on 07.12.23.
//

import Foundation
import UIKit

class Router {
    var initialViewController: UIViewController {
        let rootScene = Scene.makeMainViewScene()
        return rootScene
    }
}
