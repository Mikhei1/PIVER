//
//  Presenter.swift
//  VIP
//
//  Created by User on 07.12.23.
//

import Foundation

protocol Presentation: AnyObject {
    func presentText(text: String)
}

class Presenter: InteractorOutPut {
  
    
   
    private weak var viewcontroller: Presentation?
    
    func attach(viewController: Presentation) {
        self.viewcontroller = viewController
    }
    
    func finishedLoadText(text: String) {
        self.viewcontroller?.presentText(text: text)
    }
    
}
