//
//  Interactor.swift
//  VIP
//
//  Created by User on 07.12.23.
//

import Foundation
import Combine

protocol InteractorInput: AnyObject {
    func loadText(counter: Int)
    func fetchPosts()
}

protocol InteractorOutPut: AnyObject {
    func finishedLoadText(text: String)
}

class Interactor: InteractorInput {
    
    
    
    
    private let presenter: InteractorOutPut
    private let networkManager = NetworkManager()
    private var subsriptions: Set<AnyCancellable> = []
    var posts: [Post] = []
    
    

    init(presenter: InteractorOutPut) {
        self.presenter = presenter
    }
    
    func fetchPosts() {
        self.networkManager.fetchPosts {[weak self] a in
            
            self?.posts = a
        }
    }
    
    func loadText(counter: Int) {
        networkManager.$publish1
          //  .receive(on: DispatchQueue.main)
            .sink { newValue in
                self.presenter.finishedLoadText(text: newValue?[counter].title ?? "333")
            }.store(in: &subsriptions)
    }
}
