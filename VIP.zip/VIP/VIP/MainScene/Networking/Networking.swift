//
//  Networking.swift
//  VIP
//
//  Created by User on 07.12.23.
//


import UIKit
import Combine
import Foundation

class NetworkManager {
    
    private var cancellables: Set<AnyCancellable> = []
    @Published var publish1: [Post]?
    
    var globalPost: [Post] = []
    
    func fetchPosts(completion: @escaping ([Post]) -> Void) {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return }

        URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data) // Extract the data from the response
            .decode(type: [Post].self, decoder: JSONDecoder()) // Decode the data into an array of Post objects
            .receive(on: DispatchQueue.main) // Ensure UI updates occur on the main thread
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    break // Do nothing in case of successful completion
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: { posts in
                // Handle the array of Post objects
                print("Received posts: \(posts)")
                completion(posts)
                self.publish1 = posts
            })
            .store(in: &cancellables)
    }
}
