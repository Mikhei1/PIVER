//
//  MainViewController.swift
//  VIP
//
//  Created by User on 07.12.23.
//

import UIKit

class MainViewController: UIViewController, Presentation {
    
    var interactor: InteractorInput?
    var counter = 0

    @IBOutlet weak var inLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.interactor?.fetchPosts()
    }
    
    @IBAction func clickedButton(_ sender: Any) {
        self.interactor?.loadText(counter: self.counter)
        counter += 1
    }
    
    func presentText(text: String) {
        self.inLabel.text = text
    }
    

}
