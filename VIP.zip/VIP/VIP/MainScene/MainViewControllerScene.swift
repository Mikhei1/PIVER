//
//  MainViewControllerScene.swift
//  VIP
//
//  Created by User on 07.12.23.
//

import Foundation
import UIKit

final class Scene {
    
    static func makeMainViewScene() -> UIViewController {
        let presenter = Presenter()
        let interactor = Interactor(presenter: presenter)
        let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Main") as! MainViewController
        viewController.interactor = interactor
        presenter.attach(viewController: viewController)
        return viewController
    }   
}
